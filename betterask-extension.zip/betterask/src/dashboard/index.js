import { g as getEvents, r as reactExports, j as jsxRuntimeExports, f as formatMinutes, a as getSettings, b as getRules, d as deleteAllMemory, c as createRoot, R as React } from "../../utils.js";
import { g as generateReport } from "../../reports.js";
import { c as createRule } from "../../rules.js";
function extractPhrases(texts) {
  const freq = /* @__PURE__ */ new Map();
  const stopWords = /* @__PURE__ */ new Set(["the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with"]);
  for (const text of texts) {
    const words = text.toLowerCase().split(/\s+/).filter((w) => w.length > 3 && !stopWords.has(w));
    for (let i = 0; i < words.length - 1; i++) {
      const bigram = `${words[i]} ${words[i + 1]}`;
      freq.set(bigram, (freq.get(bigram) ?? 0) + 1);
    }
  }
  return freq;
}
async function detectLearnedRuleSuggestions() {
  const events = await getEvents();
  const THRESHOLD = 3;
  const editedByCategory = /* @__PURE__ */ new Map();
  for (const e of events) {
    if (e.userAction === "edited" && e.editedPrompt) {
      const arr = editedByCategory.get(e.category) ?? [];
      arr.push(e.editedPrompt);
      editedByCategory.set(e.category, arr);
    }
  }
  const suggestions = [];
  for (const [category, edits] of editedByCategory) {
    if (edits.length < THRESHOLD) continue;
    const phrases = extractPhrases(edits);
    for (const [phrase, count] of phrases) {
      if (count >= THRESHOLD) {
        suggestions.push({
          category,
          rule: `For ${category} requests: include "${phrase}" in the prompt.`,
          count
        });
      }
    }
    for (const e of events) {
      if (e.category === category) ;
    }
  }
  return suggestions;
}
async function createLearnedRule(suggestion) {
  return createRule(suggestion.category, suggestion.rule, "learned");
}
function StatCard({ label, value, sub, accent = "#00E5A0" }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl p-5", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-bold font-mono mb-1", style: { color: accent }, children: value }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium", style: { color: "#EEF2F7" }, children: label }),
    sub && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs mt-1", style: { color: "#3A4455" }, children: sub })
  ] });
}
function AcceptanceBar({ accepted, edited, rejected }) {
  const total = accepted + edited + rejected || 1;
  const bars = [
    { label: "Accepted", count: accepted, color: "#00E5A0" },
    { label: "Edited", count: edited, color: "#4D9EFF" },
    { label: "Rejected", count: rejected, color: "#FF6B6B" }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl p-5 space-y-3", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium", style: { color: "#EEF2F7" }, children: "Suggestion Outcomes" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex rounded-full overflow-hidden h-3", children: bars.map(({ count, color }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { width: `${count / total * 100}%`, background: color, minWidth: count > 0 ? "4px" : "0" } }, color)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-4", children: bars.map(({ label, count, color }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs", style: { color: "#7A8899" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { width: "8px", height: "8px", borderRadius: "50%", background: color, display: "inline-block", flexShrink: 0 } }),
      label,
      ": ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { color: "#EEF2F7" }, children: count })
    ] }, label)) })
  ] });
}
function Dashboard() {
  const [report, setReport] = reactExports.useState(null);
  const [rules, setRules] = reactExports.useState([]);
  const [suggestions, setSuggestions] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const loadAll = async () => {
    const [settings, rep, r, sugg] = await Promise.all([
      getSettings(),
      generateReport(),
      getRules(),
      detectLearnedRuleSuggestions()
    ]);
    const repWithMinutes = await generateReport(settings.minutesPerAvoidedFollowUp);
    setReport(repWithMinutes);
    setRules(r);
    setSuggestions(sugg);
    setLoading(false);
  };
  reactExports.useEffect(() => {
    loadAll();
  }, []);
  const handleApproveRule = async (sugg) => {
    await createLearnedRule(sugg);
    setSuggestions((prev) => prev.filter((s) => s !== sugg));
    loadAll();
  };
  const handleClearAll = async () => {
    if (!confirm("Delete all prompt history? Rules will be kept.")) return;
    await deleteAllMemory();
    loadAll();
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center min-h-screen", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm", style: { color: "#7A8899" }, children: "Loading dashboard…" }) });
  }
  if (!report) return null;
  const isEmpty = report.promptsObserved === 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto p-6 space-y-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-3xl", children: "✨" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold", style: { color: "#00E5A0" }, children: "BetterAsk" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", style: { color: "#7A8899", fontFamily: "monospace" }, children: "Local Dashboard" })
        ] })
      ] }),
      !isEmpty && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleClearAll, className: "px-4 py-2 text-sm rounded-lg transition-opacity hover:opacity-70", style: { background: "rgba(255,107,107,0.1)", color: "#FF6B6B", border: "1px solid rgba(255,107,107,0.2)" }, children: "Clear History" })
    ] }),
    isEmpty ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-20 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-5xl", children: "🤖" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium", style: { color: "#7A8899" }, children: "No prompt history yet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm max-w-sm mx-auto leading-relaxed", style: { color: "#3A4455" }, children: "Start using BetterAsk on ChatGPT, Claude, Perplexity, or Gemini. When you improve a prompt, it will appear here." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono uppercase tracking-widest mb-4", style: { color: "#3A4455" }, children: "Overview" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Prompts Observed", value: report.promptsObserved }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Prompts Improved", value: report.promptsImproved, sub: `${Math.round(report.promptsImproved / Math.max(report.promptsObserved, 1) * 100)}% of total` }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Est. Tokens Saved", value: report.estimatedTokensSaved.toLocaleString(), sub: "Rough estimate (chars/4)", accent: "#4D9EFF" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Est. Time Saved", value: formatMinutes(report.estimatedMinutesSaved), sub: "Based on avoided follow-ups", accent: "#F5C518" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        AcceptanceBar,
        {
          accepted: report.acceptedCount,
          edited: report.editedCount,
          rejected: report.rejectedCount
        }
      ),
      suggestions.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono uppercase tracking-widest mb-4", style: { color: "#F5C518" }, children: "Suggested Rules (from your patterns)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: suggestions.map((sugg, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-lg p-3", style: { background: "#111620", border: "1px solid rgba(245,197,24,0.2)" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-mono mr-2", style: { color: "#F5C518", textTransform: "uppercase" }, children: sugg.category }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", style: { color: "#EEF2F7" }, children: sugg.rule }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs ml-2", style: { color: "#3A4455" }, children: [
              "seen ",
              sugg.count,
              "×"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleApproveRule(sugg), className: "px-3 py-1.5 text-xs font-bold rounded-lg", style: { background: "#00E5A0", color: "#060910" }, children: "Approve" })
        ] }, i)) })
      ] }),
      report.topFailureCategories.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono uppercase tracking-widest mb-4", style: { color: "#3A4455" }, children: "Top Prompt Failure Categories" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: report.topFailureCategories.map(({ label, count }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-mono w-20 capitalize", style: { color: "#7A8899" }, children: label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 h-2 rounded-full overflow-hidden", style: { background: "#111620" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { height: "100%", width: `${count / report.topFailureCategories[0].count * 100}%`, background: "#FF6B6B", borderRadius: "2px" } }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-mono w-6 text-right", style: { color: "#7A8899" }, children: count })
        ] }, label)) })
      ] }),
      rules.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono uppercase tracking-widest mb-4", style: { color: "#3A4455" }, children: "Your Saved Rules" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: rules.filter((r) => r.enabled).slice(0, 8).map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 rounded-lg p-3", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: "10px", background: "#1A2030", color: "#7A8899", borderRadius: "3px", padding: "2px 7px", fontFamily: "monospace", textTransform: "uppercase", flexShrink: 0, marginTop: "2px" }, children: r.category }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm flex-1", style: { color: "#EEF2F7" }, children: r.rule }),
          r.usageCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-mono", style: { color: "#3A4455", flexShrink: 0 }, children: [
            "×",
            r.usageCount
          ] })
        ] }, r.id)) })
      ] }),
      report.recommendations.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl p-5 space-y-2", style: { background: "#111620", border: "1px solid rgba(0,229,160,0.15)" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono uppercase tracking-widest mb-3", style: { color: "#00E5A0" }, children: "Recommendations" }),
        report.recommendations.map((rec, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm", style: { color: "#7A8899", lineHeight: 1.6 }, children: [
          "→ ",
          rec
        ] }, i))
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-center", style: { color: "#3A4455", fontFamily: "monospace" }, children: "Token and time estimates are approximate. Estimates assume ~1 follow-up avoided per accepted suggestion." })
    ] })
  ] });
}
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Dashboard, {}) })
);
