import { r as reactExports, D as DEFAULT_SETTINGS, j as jsxRuntimeExports, a as getSettings, b as getRules, e as exportMemory, i as importMemory, d as deleteAllMemory, s as saveSettings, c as createRoot, R as React } from "../../utils.js";
import { c as createRule, t as toggleRule, e as editRule, r as removeRule } from "../../rules.js";
const CATEGORIES = ["writing", "coding", "research", "planning", "data", "business", "other"];
function Field({ label, hint, children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-medium", style: { color: "#EEF2F7" }, children: label }),
    hint && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs", style: { color: "#7A8899" }, children: hint }),
    children
  ] });
}
function Input({ value, onChange, type = "text", placeholder }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "input",
    {
      type,
      value,
      onChange: (e) => onChange(e.target.value),
      placeholder,
      className: "w-full px-3 py-2 text-sm rounded-lg outline-none",
      style: { background: "#111620", border: "1px solid #1A2030", color: "#EEF2F7", fontFamily: "monospace" }
    }
  );
}
function Toggle({ checked, onChange, label }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-3 cursor-pointer", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => onChange(!checked),
        className: "relative inline-flex items-center rounded-full w-10 h-5 transition-colors",
        style: { background: checked ? "#00E5A0" : "#1A2030", border: "1px solid " + (checked ? "#00E5A0" : "#222A38") },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: "inline-block w-4 h-4 rounded-full bg-white shadow transition-transform",
            style: { transform: checked ? "translateX(22px)" : "translateX(2px)" }
          }
        )
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", style: { color: "#EEF2F7" }, children: label })
  ] });
}
function Options() {
  const [tab, setTab] = reactExports.useState("general");
  const [settings, setSettings] = reactExports.useState(DEFAULT_SETTINGS);
  const [rules, setRules] = reactExports.useState([]);
  const [saved, setSaved] = reactExports.useState(false);
  const [newRule, setNewRule] = reactExports.useState("");
  const [newRuleCat, setNewRuleCat] = reactExports.useState("writing");
  const [editingId, setEditingId] = reactExports.useState(null);
  const [editText, setEditText] = reactExports.useState("");
  reactExports.useEffect(() => {
    const load = async () => {
      const [s, r] = await Promise.all([getSettings(), getRules()]);
      setSettings(s);
      setRules(r);
    };
    load();
  }, []);
  const updateSetting = (key, val) => {
    setSettings((s) => ({ ...s, [key]: val }));
  };
  const handleSave = async () => {
    await saveSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2e3);
  };
  const handleAddRule = async () => {
    if (!newRule.trim()) return;
    const r = await createRule(newRuleCat, newRule.trim());
    setRules((prev) => [...prev, r]);
    setNewRule("");
  };
  const handleDeleteRule = async (id) => {
    await removeRule(id);
    setRules((prev) => prev.filter((r) => r.id !== id));
  };
  const handleToggleRule = async (id) => {
    await toggleRule(id);
    setRules((prev) => prev.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };
  const handleSaveEdit = async (id) => {
    if (!editText.trim()) return;
    await editRule(id, editText.trim());
    setRules((prev) => prev.map((r) => r.id === id ? { ...r, rule: editText.trim() } : r));
    setEditingId(null);
  };
  const handleExport = async () => {
    const data = await exportMemory();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `betterask-memory-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const handleImport = async (e) => {
    var _a;
    const file = (_a = e.target.files) == null ? void 0 : _a[0];
    if (!file) return;
    const text = await file.text();
    try {
      const data = JSON.parse(text);
      await importMemory(data);
      alert("Memory imported successfully.");
    } catch {
      alert("Invalid file format.");
    }
  };
  const handleDeleteAll = async () => {
    if (!confirm("Delete all local memory? This cannot be undone.")) return;
    await deleteAllMemory();
    alert("All local memory deleted.");
  };
  const TABS = [
    { id: "general", label: "General" },
    { id: "api", label: "API" },
    { id: "rules", label: "Rules" },
    { id: "privacy", label: "Privacy" }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl mx-auto p-6 space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl", children: "✨" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold", style: { color: "#00E5A0" }, children: "BetterAsk" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs", style: { color: "#7A8899", fontFamily: "monospace" }, children: "Settings" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-1 rounded-lg p-1", style: { background: "#111620", border: "1px solid #1A2030" }, children: TABS.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => setTab(t.id),
        className: "flex-1 py-2 text-sm rounded-md font-medium transition-all",
        style: tab === t.id ? { background: "#1A2030", color: "#EEF2F7" } : { color: "#7A8899", background: "transparent" },
        children: t.label
      },
      t.id
    )) }),
    tab === "general" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: settings.enabled, onChange: (v) => updateSetting("enabled", v), label: "Enable BetterAsk" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: settings.autoAudit, onChange: (v) => updateSetting("autoAudit", v), label: "Auto-audit responses" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: settings.doNotLearnDefault, onChange: (v) => updateSetting("doNotLearnDefault", v), label: "Do not learn from prompts by default" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Sensitivity", hint: "How aggressively BetterAsk flags weak prompts", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: ["low", "medium", "high"].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => updateSetting("sensitivity", s),
          className: "flex-1 py-2 text-sm rounded-lg capitalize font-medium transition-all",
          style: settings.sensitivity === s ? { background: "#00E5A0", color: "#060910" } : { background: "#111620", color: "#7A8899", border: "1px solid #1A2030" },
          children: s
        },
        s
      )) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Minutes saved per avoided follow-up", hint: "Used for time-saved estimates in the dashboard", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "number",
          value: settings.minutesPerAvoidedFollowUp,
          onChange: (e) => updateSetting("minutesPerAvoidedFollowUp", parseFloat(e.target.value) || 1.5),
          min: 0.5,
          max: 30,
          step: 0.5,
          className: "w-32 px-3 py-2 text-sm rounded-lg outline-none",
          style: { background: "#111620", border: "1px solid #1A2030", color: "#EEF2F7", fontFamily: "monospace" }
        }
      ) })
    ] }),
    tab === "api" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { checked: !settings.localOnly, onChange: (v) => updateSetting("localOnly", !v), label: "Enable API mode (sends prompt to AI API)" }),
      !settings.localOnly && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg p-4 space-y-4", style: { background: "#111620", border: "1px solid rgba(0,229,160,0.15)" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs", style: { color: "#7A8899" }, children: "Your API key is stored locally and never sent to BetterAsk servers. It is only sent to your configured endpoint." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "API Key", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.apiKey, onChange: (v) => updateSetting("apiKey", v), type: "password", placeholder: "sk-..." }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "API Endpoint", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.apiEndpoint, onChange: (v) => updateSetting("apiEndpoint", v), placeholder: "https://api.openai.com/v1" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Model", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.apiModel, onChange: (v) => updateSetting("apiModel", v), placeholder: "gpt-4o-mini" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", style: { color: "#EEF2F7" }, children: "Second Opinion Model (optional)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Second Opinion API Key", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.secondOpinionKey, onChange: (v) => updateSetting("secondOpinionKey", v), type: "password", placeholder: "sk-..." }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Second Opinion Endpoint", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.secondOpinionEndpoint, onChange: (v) => updateSetting("secondOpinionEndpoint", v) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Second Opinion Model", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: settings.secondOpinionModel, onChange: (v) => updateSetting("secondOpinionModel", v), placeholder: "gpt-4o" }) })
      ] })
    ] }),
    tab === "rules" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", style: { color: "#7A8899" }, children: "Rules are applied when improving prompts. Add your preferences here." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg p-4 space-y-3", style: { background: "#111620", border: "1px solid #1A2030" }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "select",
          {
            value: newRuleCat,
            onChange: (e) => setNewRuleCat(e.target.value),
            className: "px-3 py-2 text-sm rounded-lg outline-none",
            style: { background: "#161C28", border: "1px solid #1A2030", color: "#EEF2F7" },
            children: CATEGORIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            value: newRule,
            onChange: (e) => setNewRule(e.target.value),
            onKeyDown: (e) => e.key === "Enter" && handleAddRule(),
            placeholder: "e.g. Always use lowercase SQL keywords",
            className: "flex-1 px-3 py-2 text-sm rounded-lg outline-none",
            style: { background: "#161C28", border: "1px solid #1A2030", color: "#EEF2F7" }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleAddRule,
            className: "px-4 py-2 text-sm font-bold rounded-lg",
            style: { background: "#00E5A0", color: "#060910" },
            children: "Add"
          }
        )
      ] }) }),
      rules.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-center py-4", style: { color: "#3A4455" }, children: "No rules yet. Add your first rule above." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: rules.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-lg p-3 flex items-start gap-3",
          style: { background: "#111620", border: "1px solid " + (r.enabled ? "#1A2030" : "#0C1017"), opacity: r.enabled ? 1 : 0.5 },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleToggleRule(r.id), style: { flexShrink: 0, marginTop: "2px" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { width: "14px", height: "14px", borderRadius: "3px", background: r.enabled ? "#00E5A0" : "#1A2030", border: "1px solid " + (r.enabled ? "#00E5A0" : "#222A38") } }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: "10px", background: "#1A2030", color: "#7A8899", borderRadius: "3px", padding: "1px 6px", fontFamily: "monospace", textTransform: "uppercase" }, children: r.category }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { fontSize: "10px", color: "#3A4455", fontFamily: "monospace" }, children: r.source })
              ] }),
              editingId === r.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 mt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    value: editText,
                    onChange: (e) => setEditText(e.target.value),
                    className: "flex-1 px-2 py-1 text-sm rounded outline-none",
                    style: { background: "#161C28", border: "1px solid #1A2030", color: "#EEF2F7" }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleSaveEdit(r.id), style: { fontSize: "12px", color: "#00E5A0", background: "none", border: "none", cursor: "pointer" }, children: "Save" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setEditingId(null), style: { fontSize: "12px", color: "#7A8899", background: "none", border: "none", cursor: "pointer" }, children: "Cancel" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", style: { color: "#EEF2F7" }, children: r.rule })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1 flex-shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
                setEditingId(r.id);
                setEditText(r.rule);
              }, style: { fontSize: "11px", color: "#4D9EFF", background: "none", border: "none", cursor: "pointer" }, children: "Edit" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleDeleteRule(r.id), style: { fontSize: "11px", color: "#FF6B6B", background: "none", border: "none", cursor: "pointer" }, children: "Delete" })
            ] })
          ]
        },
        r.id
      )) })
    ] }),
    tab === "privacy" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg p-4 space-y-3", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", style: { color: "#EEF2F7" }, children: "Memory" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs leading-relaxed", style: { color: "#7A8899" }, children: "BetterAsk stores prompt events and rules locally in your browser. No data is sent anywhere unless you enable API mode." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleExport, className: "px-4 py-2 text-sm rounded-lg transition-opacity hover:opacity-80", style: { background: "#1A2030", color: "#4D9EFF", border: "1px solid #222A38" }, children: "Export Memory" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-4 py-2 text-sm rounded-lg cursor-pointer transition-opacity hover:opacity-80", style: { background: "#1A2030", color: "#7A8899", border: "1px solid #222A38" }, children: [
            "Import Memory",
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: ".json", onChange: handleImport, className: "sr-only" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleDeleteAll, className: "px-4 py-2 text-sm rounded-lg transition-opacity hover:opacity-80", style: { background: "rgba(255,107,107,0.1)", color: "#FF6B6B", border: "1px solid rgba(255,107,107,0.2)" }, children: "Delete All Memory" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg p-4 text-xs space-y-2 leading-relaxed", style: { background: "#111620", border: "1px solid #1A2030", color: "#7A8899" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• No analytics. No third-party tracking." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• API keys stored only in chrome.storage.local." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• No data leaves your browser unless API mode is enabled." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "• API mode sends prompts to your configured endpoint only." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 pt-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleSave,
          className: "px-6 py-2.5 text-sm font-bold rounded-lg transition-all",
          style: { background: "#00E5A0", color: "#060910" },
          children: saved ? "Saved ✓" : "Save Settings"
        }
      ),
      saved && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", style: { color: "#00E5A0" }, children: "Settings saved!" })
    ] })
  ] });
}
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}) })
);
