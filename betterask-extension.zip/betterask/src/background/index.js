(function() {
  "use strict";
  const DEFAULT_SETTINGS = {
    enabled: true,
    sensitivity: "medium",
    apiKey: "",
    apiEndpoint: "https://api.openai.com/v1",
    apiModel: "gpt-4o-mini",
    secondOpinionKey: "",
    secondOpinionEndpoint: "https://api.openai.com/v1",
    secondOpinionModel: "gpt-4o",
    localOnly: true,
    autoAudit: false,
    doNotLearnDefault: false,
    minutesPerAvoidedFollowUp: 1.5
  };
  const KEYS = {
    settings: "ba_settings"
  };
  function get(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get(key, (result) => resolve(result[key]));
    });
  }
  async function getSettings() {
    const stored = await get(KEYS.settings);
    return { ...DEFAULT_SETTINGS, ...stored };
  }
  chrome.runtime.onInstalled.addListener(() => {
    console.log("[BetterAsk] Extension installed");
  });
  chrome.runtime.onInstalled.addListener(({ reason }) => {
    if (reason === "install") {
      chrome.tabs.create({ url: chrome.runtime.getURL("src/options/index.html") });
    }
  });
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "GET_SETTINGS") {
      getSettings().then(sendResponse);
      return true;
    }
    if (msg.type === "OPEN_DASHBOARD") {
      chrome.tabs.create({ url: chrome.runtime.getURL("src/dashboard/index.html") });
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });
})();
