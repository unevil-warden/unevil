import { r as reactExports, D as DEFAULT_SETTINGS, j as jsxRuntimeExports, f as formatMinutes, a as getSettings, g as getEvents, b as getRules, n as updateSettings, c as createRoot, R as React } from "../../utils.js";
import { g as generateReport } from "../../reports.js";
const SUPPORTED_SITES = ["chatgpt.com", "claude.ai", "perplexity.ai", "gemini.google.com"];
function getCurrentTabHost() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      var _a;
      try {
        resolve(new URL(((_a = tabs[0]) == null ? void 0 : _a.url) ?? "").hostname);
      } catch {
        resolve("");
      }
    });
  });
}
function Popup() {
  const [settings, setSettings] = reactExports.useState(DEFAULT_SETTINGS);
  const [host, setHost] = reactExports.useState("");
  const [stats, setStats] = reactExports.useState({ events: 0, rules: 0, minutesSaved: 0 });
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    const load = async () => {
      const [s, h, events, rules, report] = await Promise.all([
        getSettings(),
        getCurrentTabHost(),
        getEvents(),
        getRules(),
        generateReport()
      ]);
      setSettings(s);
      setHost(h);
      setStats({ events: events.length, rules: rules.length, minutesSaved: report.estimatedMinutesSaved });
      setLoading(false);
    };
    load();
  }, []);
  const isSupported = SUPPORTED_SITES.some((s) => host.includes(s));
  const toggleEnabled = async () => {
    const next = !settings.enabled;
    const updated = { ...settings, enabled: next };
    setSettings(updated);
    await updateSettings({ enabled: next });
  };
  const openOptions = () => chrome.runtime.openOptionsPage();
  const openDashboard = () => chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" });
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-20 text-gray-500 text-sm", children: "Loading…" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-4", style: { background: "#060910", minHeight: "260px" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-lg", children: "✨" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-bold", style: { color: "#00E5A0" }, children: "BetterAsk" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-mono px-2 py-0.5 rounded", style: { background: "#111620", color: "#3A4455", border: "1px solid #1A2030", fontSize: "9px", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "v0.1" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: toggleEnabled,
          className: "relative inline-flex items-center rounded-full w-10 h-5 transition-colors duration-200",
          style: { background: settings.enabled ? "#00E5A0" : "#1A2030" },
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "inline-block w-4 h-4 rounded-full bg-white shadow transition-transform duration-200",
              style: { transform: settings.enabled ? "translateX(22px)" : "translateX(2px)" }
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-mono px-3 py-2 rounded", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { width: "6px", height: "6px", borderRadius: "50%", background: isSupported ? "#00E5A0" : "#3A4455", flexShrink: 0, display: "inline-block" } }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { style: { color: isSupported ? "#7A8899" : "#3A4455" }, children: [
        host || "No active tab",
        isSupported ? " — supported" : " — not supported"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-2", children: [
      { n: stats.events, label: "Prompts\ntracked" },
      { n: stats.rules, label: "Saved\nrules" },
      { n: formatMinutes(stats.minutesSaved), label: "Est. time\nsaved" }
    ].map(({ n, label }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center rounded-lg p-2", style: { background: "#111620", border: "1px solid #1A2030" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold font-mono", style: { color: "#00E5A0" }, children: n }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs leading-tight mt-0.5 whitespace-pre-line", style: { color: "#7A8899", fontSize: "10px" }, children: label })
    ] }, label)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: openDashboard,
          className: "w-full text-sm rounded-lg py-2.5 font-medium transition-opacity hover:opacity-80",
          style: { background: "#111620", color: "#4D9EFF", border: "1px solid #1A2030" },
          children: "Open Dashboard"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: openOptions,
          className: "w-full text-sm rounded-lg py-2.5 font-medium transition-opacity hover:opacity-80",
          style: { background: "#111620", color: "#7A8899", border: "1px solid #1A2030" },
          children: "Settings"
        }
      )
    ] }),
    !settings.enabled && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-center", style: { color: "#3A4455", fontStyle: "italic" }, children: "BetterAsk is paused. Toggle above to resume." })
  ] });
}
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}) })
);
