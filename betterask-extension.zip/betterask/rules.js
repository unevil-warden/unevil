import { h as isoNow, k as generateId, l as addRule, b as getRules, u as updateRule, m as deleteRule } from "./utils.js";
async function createRule(category, rule, source = "manual") {
  const now = isoNow();
  const newRule = {
    id: generateId(),
    category,
    rule,
    createdAt: now,
    updatedAt: now,
    usageCount: 0,
    source,
    enabled: true
  };
  await addRule(newRule);
  return newRule;
}
async function toggleRule(id) {
  const rules = await getRules();
  const r = rules.find((r2) => r2.id === id);
  if (r) await updateRule(id, { enabled: !r.enabled });
}
async function removeRule(id) {
  await deleteRule(id);
}
async function editRule(id, rule) {
  await updateRule(id, { rule, updatedAt: isoNow() });
}
export {
  createRule as c,
  editRule as e,
  removeRule as r,
  toggleRule as t
};
